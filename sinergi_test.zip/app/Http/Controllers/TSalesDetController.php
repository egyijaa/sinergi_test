<?php

namespace App\Http\Controllers;

use App\Models\t_sales_det;
use Illuminate\Http\Request;

class TSalesDetController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\t_sales_det  $t_sales_det
     * @return \Illuminate\Http\Response
     */
    public function show(t_sales_det $t_sales_det)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\t_sales_det  $t_sales_det
     * @return \Illuminate\Http\Response
     */
    public function edit(t_sales_det $t_sales_det)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\t_sales_det  $t_sales_det
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, t_sales_det $t_sales_det)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\t_sales_det  $t_sales_det
     * @return \Illuminate\Http\Response
     */
    public function destroy(t_sales_det $t_sales_det)
    {
        //
    }
}
