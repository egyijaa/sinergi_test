

<?php $__env->startSection('container'); ?>
<!--**********************************
            Content body start
        ***********************************-->
<div class="content-body">
    <div class="container-fluid">
        <div class="row page-titles mx-0">
            <div class="col-sm-6 p-md-0">
                <div class="welcome-text">
                    <h4>Hi, Selamat Datang!</h4>
                </div>
            </div>
            <div class="col-sm-6 p-md-0 justify-content-sm-end mt-2 mt-sm-0 d-flex">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="javascript:void(0)">Table</a></li>
                    <li class="breadcrumb-item active"><a href="javascript:void(0)">Transaksi</a></li>
                </ol>
            </div>
        </div>
        <!-- row -->


        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-header justify-content-between d-flex d-inline">
                        <h4 class="card-title">Daftar Transanksi</h4>
                        <a href="<?php echo e(route('transaksi.formInput')); ?>"><i class="btn btn-sm btn-primary shadow-sm">+ Transanksi Baru</i></a>
                      </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table id="example" class="display dataTable table-striped table-bordered table-hover table-responsive-sm" style="font-size: 11px">
                                <thead>
                                    <tr>
                                        <th>No</th>
                                        <th>No Transanksi</th>
                                        <th>Tanggal</th>
                                        <th>Nama Customer</th>
                                        <th>Jumlah Barang</th>
                                        <th>Sub Total</th>
                                        <th>Diskon</th>
                                        <th>Ongkir</th>
                                        <th>Total</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                        $i = 1;
                                    ?>
                                    <?php $__currentLoopData = $t_sales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr class="selected">
                                        <td><?php echo e($i); ?></td>
                                        <td><?php echo e($item->kode); ?></td>
                                        <td><?php echo e(date('d-M-Y', strtotime($item->tgl))); ?></td>
                                        <td><?php echo e($item->m_customer->nama); ?></td>
                                        <td><?php echo e($item->jumlah_barang); ?></td>
                                        <td>Rp. <?php echo number_format($item->subtotal,2,'.',','); ?></td>
                                        <td>Rp. <?php echo number_format($item->diskon,2,'.',','); ?></td>
                                        <td>Rp. <?php echo number_format($item->ongkir,2,'.',','); ?></td>
                                        <td>Rp. <?php echo number_format($item->total_bayar,2,'.',','); ?></td>
                                    </tr>
                                    <?php
                                        $i++
                                    ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!--**********************************
            Content body end
        ***********************************-->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Software\Laravel\sinergi_test\resources\views/pages/dashboard.blade.php ENDPATH**/ ?>