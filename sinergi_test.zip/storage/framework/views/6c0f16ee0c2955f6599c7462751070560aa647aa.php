 <!--**********************************
            Header start
        ***********************************-->
        <div class="header">
            <div class="header-content">
                <nav class="navbar navbar-expand">
                    <div class="collapse navbar-collapse justify-content-between">
                        <div class=" header-content">
                            <h4>Test Mitra Sinergi Teknoindo (Laravel, PostgreSQL)</h4>
                        </div>

                        
                    </div>
                </nav>
            </div>
        </div>
        <!--**********************************
            Header end ti-comment-alt
        ***********************************--><?php /**PATH D:\Software\Laravel\sinergi_test\resources\views/layouts/header.blade.php ENDPATH**/ ?>